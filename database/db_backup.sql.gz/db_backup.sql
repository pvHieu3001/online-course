-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: localhost    Database: online_course
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_token`
--

DROP TABLE IF EXISTS `_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_token` (
  `id` bigint NOT NULL,
  `expired` bit(1) NOT NULL,
  `revoked` bit(1) NOT NULL,
  `token` varchar(512) DEFAULT NULL,
  `token_type` enum('BEARER') DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_dhh3uayldotknt9vsc0dorkap` (`token`),
  KEY `FKl8hej5e6khvvpqjr6r4mpgpo0` (`user_id`),
  CONSTRAINT `FKl8hej5e6khvvpqjr6r4mpgpo0` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_token`
--

LOCK TABLES `_token` WRITE;
/*!40000 ALTER TABLE `_token` DISABLE KEYS */;
INSERT INTO `_token` VALUES (1,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJVU0VSIl0sInVzZXIiOiJ7XCJ1c2VybmFtZVwiOlwidHVhbmh2XCIsXCJmaXJzdG5hbWVcIjpcImFkbWluXCIsXCJsYXN0bmFtZVwiOlwicGjhuqFtXCIsXCJlbWFpbFwiOlwicGhhbXZhbmhpZXUzMDAxOThAZ21haWwuY29tXCJ9Iiwic3ViIjoidHVhbmh2IiwiaWF0IjoxNzYwNDM1MjI2LCJleHAiOjE3NjA1MjE2MjZ9.kNUE1dEr4JFYlG7KAEnxdAPF4LRv6P4OWof4EiRXp5w','BEARER',1),(2,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDQzNTI2NSwiZXhwIjoxNzYwNTIxNjY1fQ.TFhOYVHHESR6c9kxlXjT-xNXD0J4zMLzFSHewd18py8','BEARER',1),(3,_binary '\0',_binary '\0','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImFkbWluXCIsXCJmaXJzdG5hbWVcIjpcImFkbWluXCIsXCJsYXN0bmFtZVwiOlwicGjhuqFtXCIsXCJlbWFpbFwiOlwicGhhbXZhbmhpZXUzMDAxOThAZ21haWwuY29tXCJ9Iiwic3ViIjoiYWRtaW4iLCJpYXQiOjE3NjA0MzU0NzEsImV4cCI6MTc2MDUyMTg3MX0.adWxmjh-JOXtfgfEAb2kMx94vJvsnUPjuXHEXCfbgN8','BEARER',2),(52,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDQ5ODEwMywiZXhwIjoxNzYwNTg0NTAzfQ.E1VCDnPE19d6Ni0U8KJeSQUeqrlcT85woUWwj9ZKQlY','BEARER',1),(102,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjA0OTgyNzYsImV4cCI6MTc2MDU4NDY3Nn0.kwoeijW0V_cbiMSgqQZZKmAlYTjrgxRvUSjvQXRfjhI','BEARER',3),(103,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDUwMDIzMSwiZXhwIjoxNzYwNTg2NjMxfQ.cL5KVextwdEtCxbO4xV8tu9BmS6093K5d5ZF1E2MOUI','BEARER',1),(152,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDUyMTE1MywiZXhwIjoxNzYwNjA3NTUzfQ.-Cqrm_78KemLdFYjgpKbcRwmGRp8K_axB1oUJzBkF0A','BEARER',1),(202,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDUyMjQzMiwiZXhwIjoxNzYwNjA4ODMyfQ.QJK2H32Oju6ZrIw68dSUUMvWrIcpQdygYquHmgVKMqg','BEARER',1),(252,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjA1OTQ4NjgsImV4cCI6MTc2MDY4MTI2OH0.JFTTvG8bxGKetqly_1rA_M5-DuHeWJk5aR7gkXjeoZI','BEARER',3),(302,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDYwNjMwNywiZXhwIjoxNzYwNjkyNzA3fQ.vT2VA4MMsXdFHyYvwEn8BxC9Xfz5Wz1_BFVsgNffGgI','BEARER',1),(303,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDYyODI4NCwiZXhwIjoxNzYwNzE0Njg0fQ.X6dIxakDBVUY85TQrq9XH_5nEuxTfvjLfdiT6S7fM-E','BEARER',1),(304,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjA2Mjg4NjQsImV4cCI6MTc2MDcxNTI2NH0.KvdrlLem6MpIMUTTZlrxdrX2mfTU7RyQmybQfejWTjs','BEARER',3),(305,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDYyODkzNywiZXhwIjoxNzYwNzE1MzM3fQ.FhcfGibpVqDHMTvAdURsQ2gcnBghdlTi62BBkdOOhso','BEARER',1),(306,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDYyOTY1NSwiZXhwIjoxNzYwNzE2MDU1fQ.oi5uBv5HDkcbtMj9Na4r7NMweubM4Lrx9lVaDCsatvc','BEARER',1),(307,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjA2MzEwMjUsImV4cCI6MTc2MDcxNzQyNX0.-uSCj6W8avIAracj3LmhmA9hwVUyyPoMovXk0CC2Wlw','BEARER',3),(308,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDYzMTE2MywiZXhwIjoxNzYwNzE3NTYzfQ.sGHVklDSQvOzo5jR_YcDsmD_ktw0U1_U3qcO0HLWv7A','BEARER',1),(352,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MDYzMTMwOCwiZXhwIjoxNzYwNzE3NzA4fQ.HEas9DbfjKOSroUEnADEWefa-9v-6Wwtb6mxrECEBIM','BEARER',1),(402,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjExNzM0NDIsImV4cCI6MTc2MTI1OTg0Mn0.2mu9htxXzMI72qW1VZ5fNymrwcVikkVdE47Ek0qaJL8','BEARER',3),(403,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjExOTUxNTIsImV4cCI6MTc2MTI4MTU1Mn0.gBv21CztE2Ls1YerP4SuBHTb-DZI-yu4W1Q7zelwSz4','BEARER',3),(404,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjEyMTAzMzIsImV4cCI6MTc2MTI5NjczMn0.fGspfJYeblXT0kyhRfacW83_T946UJ19WQGzS26ErAY','BEARER',3),(452,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjEzMTg0MjgsImV4cCI6MTc2MTQwNDgyOH0.j3hScAvZ-rQSPX1mRmJjpDYNfh-64PTvuSrcE9FprWU','BEARER',3),(453,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjEzMjExMjMsImV4cCI6MTc2MTQwNzUyM30.TJgmM2Bc5Ab4OG28I_RgDNFpZNaNjgekwdJ7b1LExVg','BEARER',3),(502,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjEzNTc0MDcsImV4cCI6MTc2MTQ0MzgwN30.4TJsb33EBHqJLv3jvCeucRUKaAFwf6fnL9JlEZAysLM','BEARER',3),(552,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjE1ODMxNzksImV4cCI6MTc2MTY2OTU3OX0.ndr6q8iyHy9vU81Dty55QcY70YTIP-m-RQu4cZybrmE','BEARER',3),(602,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjE3ODg2MDMsImV4cCI6MTc2MTg3NTAwM30.XHR_DOlpyU2foxJ-fv-5omuQQr0vHhVV70AlqN9Z_nw','BEARER',3),(603,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MTgxNjE5NywiZXhwIjoxNzYxOTAyNTk3fQ.wJf2MoQwfKSQBcdToFSBBwrUZAx0THvVRDmUpbjbO74','BEARER',1),(652,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MTgxODA2MSwiZXhwIjoxNzYxOTA0NDYxfQ.oeGWDI-ZrCQy9EN1G8A7RmOGoKI0RsTATdYKetRMHe0','BEARER',1),(702,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjE4MzgxNzQsImV4cCI6MTc2MTkyNDU3NH0.WhcP_eGVJYLWb8O7_PCjMcrggeXrYo8szZb5V0yNxso','BEARER',3),(752,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjIxODkyOTQsImV4cCI6MTc2MjI3NTY5NH0.qpuAC-SYNYjwelR4Ti0Jv1zFxPiSXOTTc1sMLCoD3zY','BEARER',3),(802,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjIyNDE3MDIsImV4cCI6MTc2MjMyODEwMn0.Til9Tm8o18ka4O9-mXk4c9dyrIO-t_ryi5kulq5u-8k','BEARER',3),(852,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjIyNzI0NDgsImV4cCI6MTc2MjM1ODg0OH0.tSY9AG3b-Ep3mWr8ez70avxj6ihVNy_7APoGzYzlTyo','BEARER',3),(902,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjI0MTY5NjcsImV4cCI6MTc2MjUwMzM2N30.ri_cK6ZvkoVqQ8b-ATLdBGSa09xZ_Sj1U3r17PTNwTI','BEARER',3),(952,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjI1MDUzMTYsImV4cCI6MTc2MjU5MTcxNn0.6VPCbVylPjfHlbhoZ5lJDWER_nojJkoKapNQK5dQ1Mg','BEARER',3),(953,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjI1MDUzMTcsImV4cCI6MTc2MjU5MTcxN30.PnF2CGq5hDmuRxVNj72UNfT-KAkk6W3CZP5Dsxdehg4','BEARER',3),(954,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjI1MDUzMjAsImV4cCI6MTc2MjU5MTcyMH0.mO4sP4z6OlLAC1jm3Twf5pCZmrRBsCBbhrQ0QFTR_3Q','BEARER',3),(1002,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjI4Njk2MDcsImV4cCI6MTc2Mjk1NjAwN30.FO5ZwZfOTUD3MSbsJ9z8rueoGXG6RgdH4FF6FXRH3Ig','BEARER',3),(1052,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjM3Mzc3ODksImV4cCI6MTc2MzgyNDE4OX0.EtofWLuIVHHoIuKFjqLW0-HrVx3Am_rrjIheekr8wB8','BEARER',3),(1053,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2MzczNzg4NiwiZXhwIjoxNzYzODI0Mjg2fQ.lCClMS1_NuWtbcWzl9tjmbl-KZe-U0DTrjmKAPVjxuY','BEARER',1),(1054,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjM3NDA2MDMsImV4cCI6MTc2MzgyNzAwM30._AnA1k3w8Z8SBNpFV4B08yxnHJd7DLLbiGQIHZvzNsc','BEARER',3),(1102,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjQwMTAwOTUsImV4cCI6MTc2NDA5NjQ5NX0.l4ArDtReFlQDqMMjjcuKEKXgmU9xinIpbEQPZWLBKAQ','BEARER',3),(1152,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjQwNDU3OTEsImV4cCI6MTc2NDEzMjE5MX0.p5C8EnrKRNQu8XBfqPr-zvnUUDYlIBwH4By3neq0t-I','BEARER',3),(1202,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2NDIxODgwMywiZXhwIjoxNzY0MzA1MjAzfQ.rJ3A4WYa9IbsauY3EaP-38OIpLmEF7XCEwujnXJ7O5M','BEARER',1),(1203,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2NDIxODgwNSwiZXhwIjoxNzY0MzA1MjA1fQ.yvfPACd7ADGfiZqrO_4jvaZBVVbEKOPeton6D5oFyFY','BEARER',1),(1204,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjQyMjU3OTMsImV4cCI6MTc2NDMxMjE5M30.LLPLuC4qIl5ZyDTfIlhS1BZW1zt6lEsERDjRqZ8ILy0','BEARER',3),(1252,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2NDM5MTI3NSwiZXhwIjoxNzY0NDc3Njc1fQ.82Z1nNMJpiDKn7rtqq0Sp6gzxoespmfgJapfvMCcn68','BEARER',1),(1302,_binary '\0',_binary '\0','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcImh1YW5kYlwiLFwiZmlyc3RuYW1lXCI6XCJIZW5yeVwiLFwibGFzdG5hbWVcIjpcIkJhXCIsXCJlbWFpbFwiOlwiZGliaHVhbkBnbWFpbC5jb21cIn0iLCJzdWIiOiJodWFuZGIiLCJpYXQiOjE3NjQ0OTA3MTUsImV4cCI6MTc2NDU3NzExNX0.iLYp16kQX3HMM7o0n7TD4Cp6_TJngl4TvhpaOO212A0','BEARER',3),(1352,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2NDgzMDc0NCwiZXhwIjoxNzY0OTE3MTQ0fQ.Xgt2u5TRWSPsl00anYGLfx-_izetTTe8q63E-02JlQ4','BEARER',1),(1353,_binary '',_binary '','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2NDgzMDg1MiwiZXhwIjoxNzY0OTE3MjUyfQ.Lt5NhvJlOQnsUWu3THQIJsT1jPxBwCc6140UwWWYRkc','BEARER',1),(1354,_binary '\0',_binary '\0','eyJhbGciOiJIUzI1NiJ9.eyJhdXRob3JpdGllcyI6WyJBRE1JTiJdLCJ1c2VyIjoie1widXNlcm5hbWVcIjpcInR1YW5odlwiLFwiZmlyc3RuYW1lXCI6XCJhZG1pblwiLFwibGFzdG5hbWVcIjpcInBo4bqhbVwiLFwiZW1haWxcIjpcInBoYW12YW5oaWV1MzAwMTk4QGdtYWlsLmNvbVwifSIsInN1YiI6InR1YW5odiIsImlhdCI6MTc2NDgzMTIyMCwiZXhwIjoxNzY0OTE3NjIwfQ._DqEpF0Xd3G28vgJhAsLPfTGGlFcu549Qp4o39-tEKM','BEARER',1);
/*!40000 ALTER TABLE `_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_token_seq`
--

DROP TABLE IF EXISTS `_token_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_token_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_token_seq`
--

LOCK TABLES `_token_seq` WRITE;
/*!40000 ALTER TABLE `_token_seq` DISABLE KEYS */;
INSERT INTO `_token_seq` VALUES (1451);
/*!40000 ALTER TABLE `_token_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `affiliate_links`
--

DROP TABLE IF EXISTS `affiliate_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_links` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `original_price` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `click_count` int DEFAULT NULL,
  `status` bit(1) DEFAULT NULL,
  `target_url` text,
  `created_by` bigint DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4c886t2tx9hwucxqe2pu4xp45` (`created_by`),
  KEY `FKmpjtt2ifdevy770h88sfaaww6` (`updated_by`),
  CONSTRAINT `FK4c886t2tx9hwucxqe2pu4xp45` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKmpjtt2ifdevy770h88sfaaww6` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `affiliate_links`
--

LOCK TABLES `affiliate_links` WRITE;
/*!40000 ALTER TABLE `affiliate_links` DISABLE KEYS */;
INSERT INTO `affiliate_links` VALUES (1,'200.000',0,_binary '','https://s.shopee.vn/2g2JpBlTbA',NULL,'https://down-zl-vn.img.susercontent.com/vn-11134207-7ra0g-m712isvlm15kd0.webp',NULL,'Lọ hoa Bát Tràng, bình hoa gốm sứ, lọ hoa, chuông mộc cắm hoa Gốm Xuân Xưa, bình hoa, bình hoa decor, bình cắm hoa','180.000','2025-10-06 23:50:16.332116','2025-10-06 23:50:16.332116'),(2,'400.000',0,_binary '','https://down-zl-vn.img.susercontent.com/sg-11134201-23020-wfzpfjljlbnvcc.webp',NULL,'https://down-zl-vn.img.susercontent.com/sg-11134201-23020-wfzpfjljlbnvcc.webp',NULL,'Lọ Hoa Lọ Hoa Decor Bộ 3 Lọ hoa dáng Chuông gốm sứ vẽ 100% lọ gốm men lạnh gốm sứ cao cấp Bát Tràng','315.000','2025-10-07 00:44:32.781108','2025-10-07 00:19:14.436040'),(3,'200.000',0,_binary '','https://s.shopee.vn/AUlBE7vegJ',NULL,'https://down-zl-vn.img.susercontent.com/sg-11134201-22090-kc2qfzhgn3hv8c.webp',NULL,'Lọ hoa, bình hoa, bình hoa gốm, bình hoa decor, gốm sứ, cắm hoa tươi, hoa khô phong cách Bắc Âu','119.000','2025-10-07 00:46:02.008998','2025-10-07 00:46:02.008998'),(4,'900.000',0,_binary '','https://s.shopee.vn/1VqMVgWa4u',NULL,'https://down-cvs-vn.img.susercontent.com/vn-11134207-7qukw-lg7qt9ubgxyv88.webp',NULL,'Lọ hoa gốm sứ bát tràng cao cấp bình cắm hoa đẹp lọ hoa gốm sứ trang trí lọ decor','850.000','2025-10-07 00:47:07.631316','2025-10-07 00:47:07.631316'),(5,'300.000',0,_binary '','https://s.shopee.vn/1BDW7ND75H',NULL,'https://down-cvs-vn.img.susercontent.com/vn-11134207-820l4-mfdh54etfwni18.webp',NULL,'Bức Tranh \"Back to the Sun\" - Tranh Hiện Đại - Tranh Cô Gái - Tranh Châu Âu - Tranh Trừu Tượng - Tranh Ấn Tượng','269.000','2025-10-07 00:51:30.580198','2025-10-07 00:51:30.580198'),(6,'300.000',0,_binary '','https://s.shopee.vn/LeP7ydB5p',NULL,'https://down-cvs-vn.img.susercontent.com/vn-11134207-7ras8-mcyvw4qq84gs64.webp',NULL,'Bức Tranh \"Face the Void\" - Tranh Chân Dung Trừu Tượng - Tranh Canvas - Tranh Sofa - Tranh Phòng Khách- Tranh Sang Trọng','269.000','2025-10-07 00:53:40.710195','2025-10-07 00:53:40.710195'),(7,'300.000',0,_binary '','https://s.shopee.vn/6KvcH3x7Zt',NULL,'https://down-cvs-vn.img.susercontent.com/vn-11134207-7ras8-mdin6ga1ahin30.webp',NULL,'Bức Tranh \"Phiêu Diêu\" - Tranh Treo Tường - Tranh Decor - Tranh Canvas - Tranh Phòng Khách - Tranh Sofa - Reny Luxury','269.000','2025-10-07 00:54:26.187204','2025-10-07 00:54:26.187204'),(8,'200.000',0,_binary '','https://s.shopee.vn/AUlBEn1R4K',NULL,'https://down-cvs-vn.img.susercontent.com/cn-11134207-7qukw-lkgbuqzimojq9d.webp',NULL,'Da Tou-30*40cm/40*50cm-Tự làm tranh sơn dầu kỹ thuật số handmade chữa bệnh bức tranh acrylic làm bằng tay màu ..','154.000','2025-10-07 00:55:41.666906','2025-10-07 00:55:41.666906'),(9,'700.000',0,_binary '','https://s.shopee.vn/1g9mig5Mg7',NULL,'https://down-cvs-vn.img.susercontent.com/sg-11134201-7rauz-maobhv2q1pjke0.webp',NULL,'Đèn LED YONUO, đèn trần, đèn chùm, đèn pha lê, đèn hành lang, đèn tường, đèn phòng ngủ, đèn tủ quần áo, đè','550.000','2025-10-07 00:57:17.147200','2025-10-07 00:57:17.147200'),(10,'700.000',0,_binary '','https://s.shopee.vn/9zoue28RWI',NULL,'https://down-cvs-vn.img.susercontent.com/7928249478ca82d6be742bf3b68fbf9c.webp',NULL,'Đèn chùm sáng tạo Bàn ăn Đèn chùm Đèn chùm hiện đại Đèn chùm đơn giản Đèn chùm trang trí Đèn chùm','643.500','2025-10-07 00:57:51.796259','2025-10-07 00:57:51.796259'),(11,'400.000',0,_binary '','https://s.shopee.vn/AKRl2gb1hW',NULL,'https://down-cvs-vn.img.susercontent.com/1f3e68177a43a23b3a13c2063a004448.webp',NULL,'Đèn chùm đơn giản Đèn chùm trang trí Bàn ăn Đèn chùm sáng tạo Đèn chùm Bắc Âu Đèn chùm hiện đại Đèn chùm','220.000','2025-10-07 00:58:28.098124','2025-10-07 00:58:28.098124'),(12,'60.000',0,_binary '','https://s.shopee.vn/7V7ZfdQJOf',NULL,'https://down-cvs-vn.img.susercontent.com/sg-11134201-7rdvk-mda3st73du8k4f.webp',NULL,'[SVK] Đệm Ghế In Dày Đệm Ghế Văn Phòng Bốn Mùa Lớp Học Sinh Phân Mông Thảm Ghế Ăn Thảm Tatami IKFG','44.000','2025-10-07 01:00:53.221055','2025-10-07 01:00:53.221055');
/*!40000 ALTER TABLE `affiliate_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_tag`
--

DROP TABLE IF EXISTS `blog_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_tag` (
  `blog_id` int NOT NULL,
  `tag_id` bigint NOT NULL,
  PRIMARY KEY (`blog_id`,`tag_id`),
  KEY `FKjlyy8ctkwnajrr890ri42ealy` (`tag_id`),
  CONSTRAINT `FKdl2hedc2u6i0kw0q5lg31ipmw` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`),
  CONSTRAINT `FKjlyy8ctkwnajrr890ri42ealy` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_tag`
--

LOCK TABLES `blog_tag` WRITE;
/*!40000 ALTER TABLE `blog_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `content` text,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `is_display_hot` bit(1) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `status` bit(1) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjidd8cjtc34c0i5h0f88x062t` (`created_by`),
  KEY `FK2o77ydbpqak4c9usc825x5qyo` (`updated_by`),
  CONSTRAINT `FK2o77ydbpqak4c9usc825x5qyo` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKjidd8cjtc34c0i5h0f88x062t` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_items`
--

DROP TABLE IF EXISTS `cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `added_at` date DEFAULT NULL,
  `cart_id` int DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  `price` double DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKbhw4r3ymojowg2oitk1q92anh` (`created_by`),
  KEY `FKoagcxwgqf1r0cx578r4phswe9` (`updated_by`),
  CONSTRAINT `FKbhw4r3ymojowg2oitk1q92anh` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKoagcxwgqf1r0cx578r4phswe9` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_items`
--

LOCK TABLES `cart_items` WRITE;
/*!40000 ALTER TABLE `cart_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `carts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `coupon_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKrsblgd5p1feesxvu4ujy9sdyc` (`created_by`),
  KEY `FK4wlpepgnagu6qrcyqwwtewr3t` (`updated_by`),
  CONSTRAINT `FK4wlpepgnagu6qrcyqwwtewr3t` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKrsblgd5p1feesxvu4ujy9sdyc` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts`
--

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `is_quick_view` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `number_course` int DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `status` bit(1) DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5yfru0au6kpyqs4tonky5vfne` (`created_by`),
  KEY `FKnbfq7vefwik42v5ka12ekr4hv` (`updated_by`),
  CONSTRAINT `FK5yfru0au6kpyqs4tonky5vfne` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKnbfq7vefwik42v5ka12ekr4hv` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (6,'2025-10-08 11:50:39.616394','2025-10-15 12:55:31.366027','','','17622ab5-5278-4b1a-84ba-82c67fa85b30_udemyfree.png',_binary '\0','Udemy Course',9,NULL,'udemy-course',_binary '',NULL,3),(7,'2025-10-14 11:20:16.871484','2025-10-28 02:06:45.162427','','t','',_binary '','AWS Cloud System',2,NULL,'aws-cloud-system',_binary '',NULL,3),(8,'2025-10-14 11:22:39.636170','2025-10-14 11:22:39.636170',NULL,NULL,'',_binary '','Programming - Lập trình ứng dụng',5,NULL,'programming---lap-trinh-ung-dung',_binary '',NULL,NULL),(9,'2025-10-15 12:46:43.653441','2025-10-15 12:46:43.653441',NULL,NULL,'',_binary '','Database - Cơ sở dữ liệu',1,NULL,'database---co-so-du-lieu',_binary '',3,3),(10,'2025-10-15 12:52:56.533113','2025-10-15 12:52:56.533113',NULL,NULL,'',_binary '','Graphic Design - Thiết kế đồ họa & 3D',4,NULL,'graphic-design---thiet-ke-o-hoa--3d',_binary '',3,3),(11,'2025-10-28 02:01:48.763942','2025-10-28 02:01:48.763942',NULL,NULL,'',_binary '','AI Tutorial - Deep Learning',4,NULL,'ai-tutorial---deep-learning',_binary '',3,3);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `discount_value` bigint NOT NULL,
  `expire_at` datetime(6) NOT NULL,
  `max_discount_amount` bigint NOT NULL,
  `min_order_value` bigint NOT NULL,
  `start_at` datetime(6) NOT NULL,
  `usage_count` int NOT NULL,
  `usage_limit` int NOT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5ta2iuowjf2sx01vtu35oi2an` (`created_by`),
  KEY `FKn9hadn512ka5u4fcs360r3cai` (`updated_by`),
  CONSTRAINT `FK5ta2iuowjf2sx01vtu35oi2an` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKn9hadn512ka5u4fcs360r3cai` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_tag`
--

DROP TABLE IF EXISTS `course_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_tag` (
  `course_id` int NOT NULL,
  `tag_id` bigint NOT NULL,
  PRIMARY KEY (`course_id`,`tag_id`),
  KEY `FK4xljwd6thh893y5t81btpen5q` (`tag_id`),
  CONSTRAINT `FK4xljwd6thh893y5t81btpen5q` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`),
  CONSTRAINT `FK7om0f3y4q6v90v5mv8femot2g` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_tag`
--

LOCK TABLES `course_tag` WRITE;
/*!40000 ALTER TABLE `course_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_url`
--

DROP TABLE IF EXISTS `course_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_url` (
  `course_id` int NOT NULL,
  `url_id` bigint NOT NULL,
  PRIMARY KEY (`course_id`,`url_id`),
  KEY `FK13m455gqtyqfxor355vbsnm2e` (`url_id`),
  CONSTRAINT `FK13m455gqtyqfxor355vbsnm2e` FOREIGN KEY (`url_id`) REFERENCES `urls` (`id`),
  CONSTRAINT `FKf0bkp5o5ck5y42d4gfj94k83g` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_url`
--

LOCK TABLES `course_url` WRITE;
/*!40000 ALTER TABLE `course_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `content` text,
  `course_benefits` text,
  `description` text,
  `image_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `is_display_hot` bit(1) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` int DEFAULT NULL,
  `rating` double DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `source_url` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `total_rating` int DEFAULT NULL,
  `total_students` int DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK72l5dj585nq7i6xxv1vj51lyn` (`category_id`),
  KEY `FK4u40nf46n1nqa5h38sn5g17ac` (`created_by`),
  KEY `FKltltsxweucdii0i94jtyla6wg` (`updated_by`),
  CONSTRAINT `FK4u40nf46n1nqa5h38sn5g17ac` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FK72l5dj585nq7i6xxv1vj51lyn` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `FKltltsxweucdii0i94jtyla6wg` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `device` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `method` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `page_id` varchar(255) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9617l9av8npure5bik77ihfra` (`created_by`),
  KEY `FKlrkcvu85j3xmo7ev3i0xomju1` (`updated_by`),
  CONSTRAINT `FK9617l9av8npure5bik77ihfra` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKlrkcvu85j3xmo7ev3i0xomju1` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES (20010,'2025-11-30 17:58:58.237139','2025-11-30 17:58:58.237139','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20011,'2025-11-30 17:59:34.221430','2025-11-30 17:59:34.221430','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20012,'2025-11-30 18:00:34.222251','2025-11-30 18:00:34.222251','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20013,'2025-11-30 18:01:34.278740','2025-11-30 18:01:34.278740','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20014,'2025-11-30 18:02:34.235301','2025-11-30 18:02:34.235301','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20015,'2025-11-30 18:03:34.244555','2025-11-30 18:03:34.244555','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20016,'2025-11-30 18:04:34.341725','2025-11-30 18:04:34.341725','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20017,'2025-11-30 18:05:34.340081','2025-11-30 18:05:34.340081','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20018,'2025-11-30 18:06:34.280969','2025-11-30 18:06:34.280969','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20019,'2025-11-30 18:07:34.225609','2025-11-30 18:07:34.225609','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20020,'2025-11-30 18:08:34.295434','2025-11-30 18:08:34.295434','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20021,'2025-11-30 18:09:34.231514','2025-11-30 18:09:34.231514','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20022,'2025-11-30 18:10:34.268823','2025-11-30 18:10:34.268823','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20023,'2025-11-30 18:11:34.236828','2025-11-30 18:11:34.236828','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20024,'2025-11-30 18:12:34.235807','2025-11-30 18:12:34.235807','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20025,'2025-11-30 18:13:34.313827','2025-11-30 18:13:34.313827','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20026,'2025-11-30 18:14:34.289407','2025-11-30 18:14:34.289407','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20027,'2025-11-30 18:15:34.287527','2025-11-30 18:15:34.287527','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20028,'2025-11-30 18:16:34.267590','2025-11-30 18:16:34.267590','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20029,'2025-11-30 18:17:34.326182','2025-11-30 18:17:34.326182','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20030,'2025-11-30 18:18:34.357204','2025-11-30 18:18:34.357204','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.121','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20031,'2025-11-30 18:19:34.481045','2025-11-30 18:19:34.481045','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.213','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20032,'2025-11-30 18:20:34.344496','2025-11-30 18:20:34.344496','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.213','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20033,'2025-11-30 18:21:34.381040','2025-11-30 18:21:34.381040','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.114.168','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20034,'2025-11-30 18:22:34.398084','2025-11-30 18:22:34.398084','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.214.118','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20035,'2025-11-30 18:23:34.290464','2025-11-30 18:23:34.290464','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.213','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20036,'2025-11-30 18:24:34.328871','2025-11-30 18:24:34.328871','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.214.118','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20037,'2025-11-30 18:25:34.381276','2025-11-30 18:25:34.381276','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20038,'2025-11-30 18:26:34.363421','2025-11-30 18:26:34.363421','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.214.118','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20039,'2025-11-30 18:27:34.388973','2025-11-30 18:27:34.388973','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.114.168','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20040,'2025-11-30 18:28:34.328352','2025-11-30 18:28:34.328352','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.114.168','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20041,'2025-11-30 18:29:34.362709','2025-11-30 18:29:34.362709','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.214.118','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20042,'2025-11-30 18:30:34.376987','2025-11-30 18:30:34.376987','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.179.104','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20043,'2025-11-30 18:31:34.517944','2025-11-30 18:31:34.517944','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20044,'2025-11-30 18:32:34.258327','2025-11-30 18:32:34.258327','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20045,'2025-11-30 18:33:34.266933','2025-11-30 18:33:34.266933','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20046,'2025-11-30 18:34:34.341814','2025-11-30 18:34:34.341814','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20047,'2025-11-30 18:35:34.339573','2025-11-30 18:35:34.339573','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20048,'2025-11-30 18:36:34.264108','2025-11-30 18:36:34.264108','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20049,'2025-11-30 18:37:34.267054','2025-11-30 18:37:34.267054','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20050,'2025-11-30 18:38:34.328188','2025-11-30 18:38:34.328188','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20051,'2025-11-30 18:39:34.282658','2025-11-30 18:39:34.282658','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20052,'2025-11-30 18:40:34.273419','2025-11-30 18:40:34.273419','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20053,'2025-11-30 18:41:34.312669','2025-11-30 18:41:34.312669','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20054,'2025-11-30 18:42:34.341339','2025-11-30 18:42:34.341339','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20055,'2025-11-30 18:43:34.337037','2025-11-30 18:43:34.337037','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20056,'2025-11-30 18:44:34.325378','2025-11-30 18:44:34.325378','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20057,'2025-11-30 18:45:34.295438','2025-11-30 18:45:34.295438','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20058,'2025-11-30 18:46:34.402746','2025-11-30 18:46:34.402746','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20059,'2025-11-30 18:47:34.289495','2025-11-30 18:47:34.289495','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20060,'2025-11-30 18:48:34.377566','2025-11-30 18:48:34.377566','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.68.211.212','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20061,'2025-11-30 18:49:34.402831','2025-11-30 18:49:34.402831','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.114.169','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20062,'2025-11-30 18:50:34.352249','2025-11-30 18:50:34.352249','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.114.169','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20063,'2025-11-30 18:51:34.410932','2025-11-30 18:51:34.410932','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.193.120','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20064,'2025-11-30 18:52:34.405678','2025-11-30 18:52:34.405678','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 162.158.179.103','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20065,'2025-11-30 18:53:34.414685','2025-11-30 18:53:34.414685','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.214.119','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20066,'2025-11-30 18:54:34.512942','2025-11-30 18:54:34.512942','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20067,'2025-11-30 18:55:34.287195','2025-11-30 18:55:34.287195','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20068,'2025-11-30 18:56:34.294799','2025-11-30 18:56:34.294799','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20069,'2025-11-30 18:57:34.317077','2025-11-30 18:57:34.317077','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20070,'2025-11-30 18:58:34.355295','2025-11-30 18:58:34.355295','get_all_blog','desktop','2405:4802:83d1:d7c0:d8e9:b1bc:b637:185f, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20071,'2025-11-30 20:52:32.363453','2025-11-30 20:52:32.363453','get_all_blog','desktop','159.69.112.56, 172.70.240.9','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20072,'2025-11-30 20:52:33.134219','2025-11-30 20:52:33.134219','get_all_blog','desktop','159.69.112.56, 172.70.240.155','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20073,'2025-11-30 22:17:07.294197','2025-11-30 22:17:07.294197','get_all_blog','desktop','162.55.173.32, 172.71.164.53','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/crypto','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20074,'2025-11-30 22:17:07.293400','2025-11-30 22:17:07.293400','get_all_blog','desktop','162.55.173.32, 172.71.164.53','GET','view_blog','http://hocfree.vn/api/v1/user/blog/type/crypto?search=','https://hocfree.vn/crypto','http://hocfree.vn/api/v1/user/blog/type/crypto?search=','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20075,'2025-11-30 22:17:07.686124','2025-11-30 22:17:07.686124','get_all_blog','desktop','162.55.173.32, 172.71.164.53','GET','view_blog','http://hocfree.vn/api/v1/user/blog/type/crypto?search=','https://hocfree.vn/crypto','http://hocfree.vn/api/v1/user/blog/type/crypto?search=','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20076,'2025-11-30 22:17:07.703525','2025-11-30 22:17:07.703525','get_all_blog','desktop','162.55.173.32, 172.71.164.53','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/crypto','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20077,'2025-11-30 22:20:27.901819','2025-11-30 22:20:27.901819','get_all_blog','desktop','49.13.140.247, 172.70.248.116','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',NULL,NULL),(20078,'2025-11-30 22:20:27.921578','2025-11-30 22:20:27.921578','get_all_course','desktop','49.13.140.247, 172.70.248.117','GET','view_course','http://hocfree.vn/api/v1/user/course?status=active&search=&tag=&isDisplayHot=&page=-1&size=15','https://hocfree.vn/tat-ca-khoa-hoc','http://hocfree.vn/api/v1/user/course?status=active&search=&tag=&isDisplayHot=&page=-1&size=15','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',NULL,NULL),(20079,'2025-11-30 22:37:24.277540','2025-11-30 22:37:24.277540','get_all_blog','desktop','88.99.123.107, 172.68.192.168','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/thu-thuat-huu-ich','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20080,'2025-11-30 22:37:24.279993','2025-11-30 22:37:24.279993','get_all_blog','desktop','88.99.123.107, 172.68.192.169','GET','view_blog','http://hocfree.vn/api/v1/user/blog/type/tips?search=','https://hocfree.vn/thu-thuat-huu-ich','http://hocfree.vn/api/v1/user/blog/type/tips?search=','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20081,'2025-11-30 22:37:25.099708','2025-11-30 22:37:25.099708','get_all_blog','desktop','88.99.123.107, 172.70.243.131','GET','view_blog','http://hocfree.vn/api/v1/user/blog/type/tips?search=','https://hocfree.vn/thu-thuat-huu-ich','http://hocfree.vn/api/v1/user/blog/type/tips?search=','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20082,'2025-11-30 22:37:25.113628','2025-11-30 22:37:25.113628','get_all_blog','desktop','88.99.123.107, 172.70.243.132','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/thu-thuat-huu-ich','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20083,'2025-11-30 22:51:13.722596','2025-11-30 22:51:13.722596','get_all_blog','desktop','49.13.65.76, 172.68.193.167','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/suu-tam','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20084,'2025-11-30 22:51:13.719771','2025-11-30 22:51:13.719771','get_all_blog','desktop','49.13.65.76, 172.68.193.167','GET','view_blog','http://hocfree.vn/api/v1/user/blog/type/archive?search=','https://hocfree.vn/suu-tam','http://hocfree.vn/api/v1/user/blog/type/archive?search=','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20085,'2025-11-30 22:53:47.394272','2025-11-30 22:53:47.394272','get_all_blog','desktop','49.13.218.227, 172.68.193.167','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20086,'2025-11-30 23:50:05.885879','2025-11-30 23:50:05.885879','get_all_blog','desktop','167.235.254.135, 162.158.94.42','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/chung-khoan','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20087,'2025-11-30 23:50:05.892891','2025-11-30 23:50:05.892891','get_all_blog','desktop','167.235.254.135, 162.158.94.42','GET','view_blog','http://hocfree.vn/api/v1/user/blog/type/stock?search=','https://hocfree.vn/chung-khoan','http://hocfree.vn/api/v1/user/blog/type/stock?search=','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',NULL,NULL),(20088,'2025-12-01 03:52:40.208627','2025-12-01 03:52:40.208627','get_all_blog','desktop','171.224.180.37, 162.158.107.36','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20089,'2025-12-01 03:52:40.637667','2025-12-01 03:52:40.637667','get_all_blog','desktop','171.224.180.37, 162.158.170.154','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20090,'2025-12-01 18:21:02.893349','2025-12-01 18:21:02.893349','get_all_blog','desktop','113.160.154.190, 172.71.214.118','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20091,'2025-12-01 18:37:25.880941','2025-12-01 18:37:25.880941','get_all_blog','desktop','113.160.154.190, 162.158.114.169','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20092,'2025-12-01 18:37:26.208908','2025-12-01 18:37:26.208908','get_all_blog','desktop','113.160.154.190, 162.158.114.169','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20093,'2025-12-02 00:49:09.356571','2025-12-02 00:49:09.356571','get_all_blog','desktop','204.101.161.15, 162.159.102.105','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20094,'2025-12-02 00:49:10.313211','2025-12-02 00:49:10.313211','get_all_blog','desktop','204.101.161.15, 162.159.102.105','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20095,'2025-12-02 19:58:36.404997','2025-12-02 19:58:36.404997','get_all_blog','desktop','118.69.6.189, 172.68.164.147','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20096,'2025-12-02 19:58:37.574153','2025-12-02 19:58:37.574153','get_all_blog','desktop','118.69.6.189, 172.68.164.15','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20097,'2025-12-02 19:59:08.221292','2025-12-02 19:59:08.221292','get_all_blog','desktop','118.69.6.189, 172.70.208.64','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20098,'2025-12-02 19:59:38.262308','2025-12-02 19:59:38.262308','get_all_blog','desktop','118.69.6.189, 162.158.162.100','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20099,'2025-12-02 20:00:08.139492','2025-12-02 20:00:08.139492','get_all_blog','desktop','118.69.6.189, 172.70.208.64','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20100,'2025-12-02 20:00:38.132985','2025-12-02 20:00:38.132985','get_all_blog','desktop','118.69.6.189, 162.158.108.66','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20101,'2025-12-02 20:00:56.193021','2025-12-02 20:00:56.193021','get_all_blog','desktop','118.69.6.189, 162.158.108.66','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20102,'2025-12-02 20:00:56.228127','2025-12-02 20:00:56.228127','get_all_course','desktop','118.69.6.189, 162.158.108.66','GET','view_course','http://hocfree.vn/api/v1/user/course?status=active&search=&tag=&isDisplayHot=&page=-1&size=15','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/course?status=active&search=&tag=&isDisplayHot=&page=-1&size=15','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20103,'2025-12-02 20:00:56.644820','2025-12-02 20:00:56.644820','get_all_blog','desktop','118.69.6.189, 162.158.108.66','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20104,'2025-12-02 20:00:59.698353','2025-12-02 20:00:59.698353','get_all_blog','desktop','118.69.6.189, 162.158.108.66','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20105,'2025-12-02 20:00:59.719583','2025-12-02 20:00:59.719583','get_all_blog','desktop','118.69.6.189, 162.158.108.66','GET','view_blog','http://hocfree.vn/api/v1/user/blog/type/stock?search=','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/blog/type/stock?search=','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20106,'2025-12-02 20:00:59.995039','2025-12-02 20:00:59.995039','get_all_blog','desktop','118.69.6.189, 162.158.108.66','GET','view_blog','http://hocfree.vn/api/v1/user/blog/type/stock?search=','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/blog/type/stock?search=','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20107,'2025-12-02 20:01:00.013532','2025-12-02 20:01:00.013532','get_all_blog','desktop','118.69.6.189, 162.158.108.66','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20108,'2025-12-02 20:01:01.880870','2025-12-02 20:01:01.880870','get_all_blog','desktop','118.69.6.189, 162.158.108.66','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20109,'2025-12-02 20:01:02.252794','2025-12-02 20:01:02.252794','get_all_blog','desktop','118.69.6.189, 162.158.108.66','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',NULL,NULL),(20110,'2025-12-03 08:33:41.413672','2025-12-03 08:33:41.413672','get_all_blog','desktop','2405:4802:83d1:d7c0:f524:abde:8694:97a4, 162.158.114.91','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20111,'2025-12-03 08:33:42.117557','2025-12-03 08:33:42.117557','get_all_blog','desktop','2405:4802:83d1:d7c0:f524:abde:8694:97a4, 162.158.114.91','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20112,'2025-12-03 08:33:48.991891','2025-12-03 08:33:48.991891','get_all_blog','desktop','2405:4802:83d1:d7c0:f524:abde:8694:97a4, 162.158.114.91','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/khoa-hoc-theo-chu-de/udemy-course','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20113,'2025-12-03 08:33:49.252605','2025-12-03 08:33:49.252605','get_all_blog','desktop','2405:4802:83d1:d7c0:f524:abde:8694:97a4, 162.158.114.91','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/khoa-hoc-theo-chu-de/udemy-course','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20114,'2025-12-03 08:33:49.440037','2025-12-03 08:33:49.440037','get_all_blog','desktop','2405:4802:83d1:d7c0:f524:abde:8694:97a4, 162.158.114.91','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/khoa-hoc-theo-chu-de/udemy-course','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20115,'2025-12-03 08:33:50.775401','2025-12-03 08:33:50.775401','get_all_blog','desktop','2405:4802:83d1:d7c0:f524:abde:8694:97a4, 162.158.114.91','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20116,'2025-12-03 08:33:51.121168','2025-12-03 08:33:51.121168','get_all_blog','desktop','2405:4802:83d1:d7c0:f524:abde:8694:97a4, 162.158.114.91','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20117,'2025-12-04 00:55:05.787416','2025-12-04 00:55:05.787416','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 162.158.193.236','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20118,'2025-12-04 00:55:06.150157','2025-12-04 00:55:06.150157','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 162.158.193.237','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20119,'2025-12-04 00:55:36.962807','2025-12-04 00:55:36.962807','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 162.158.193.120','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20120,'2025-12-04 00:56:07.084605','2025-12-04 00:56:07.084605','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20121,'2025-12-04 00:56:37.102022','2025-12-04 00:56:37.102022','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 162.158.179.103','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20122,'2025-12-04 00:57:06.984307','2025-12-04 00:57:06.984307','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 162.158.179.103','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20123,'2025-12-04 00:57:37.153271','2025-12-04 00:57:37.153271','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20124,'2025-12-04 00:58:06.951898','2025-12-04 00:58:06.951898','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20125,'2025-12-04 00:58:36.267858','2025-12-04 00:58:36.267858','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20126,'2025-12-04 00:59:18.952344','2025-12-04 00:59:18.952344','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20127,'2025-12-04 00:59:47.728586','2025-12-04 00:59:47.728586','get_all_blog','desktop','2405:4802:8411:e7c0:b154:4c67:bb99:eadf, 172.71.218.72','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20128,'2025-12-05 17:57:35.899866','2025-12-05 17:57:35.899866','get_all_blog','desktop','113.160.154.190, 162.158.114.169','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20129,'2025-12-05 17:57:36.510931','2025-12-05 17:57:36.510931','get_all_blog','desktop','113.160.154.190, 162.158.114.169','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20130,'2025-12-05 18:03:42.676410','2025-12-05 18:03:42.676410','get_all_blog','desktop','113.160.154.190, 162.158.114.169','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20131,'2025-12-05 18:03:43.023364','2025-12-05 18:03:43.023364','get_all_blog','desktop','113.160.154.190, 162.158.114.169','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20132,'2025-12-08 00:21:41.003766','2025-12-08 00:21:41.003766','get_all_blog','desktop','1.54.176.238, 172.70.208.64','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL),(20133,'2025-12-08 00:21:41.868805','2025-12-08 00:21:41.868805','get_all_blog','desktop','1.54.176.238, 108.162.227.111','GET','view_blog','http://hocfree.vn/api/v1/user/affiliate/random','https://www.hocfree.vn/','http://hocfree.vn/api/v1/user/affiliate/random','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',NULL,NULL);
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL,
  `content` varchar(255) NOT NULL,
  `is_deleted` bit(1) DEFAULT NULL,
  `is_read` bit(1) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  `order_id` int DEFAULT NULL,
  `price` double DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKs2wcthlv8qp34l56jcwtgj64q` (`created_by`),
  KEY `FKl145d42twpl0wlnorqvtr7b45` (`updated_by`),
  CONSTRAINT `FKl145d42twpl0wlnorqvtr7b45` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKs2wcthlv8qp34l56jcwtgj64q` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `coupon_id` int DEFAULT NULL,
  `discount_amount` double DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `sub_total` double NOT NULL,
  `total_amount` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `amount` double NOT NULL,
  `order_id` int NOT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK44957q7sogi6mtk6hs19kgycu` (`created_by`),
  KEY `FKe7bl1gym2x7osiy1qkpmvq5dl` (`updated_by`),
  CONSTRAINT `FK44957q7sogi6mtk6hs19kgycu` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKe7bl1gym2x7osiy1qkpmvq5dl` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (2,'TikTok'),(3,'AI'),(6,'GameHot'),(8,'suutam'),(9,'Khóa học Udemy'),(10,'Khóa học Python'),(11,'The Complete Python Pro Bootcamp'),(12,'100 Days of Code: The Complete Python Pro Bootcamp'),(13,'Thiết kế đồ họa'),(14,'Adobe Illustrator'),(15,'After Effects'),(16,'Adobe'),(17,'Newbies'),(18,'docker'),(19,'Docker từ cơ bản đến nâng cao'),(20,'Advanced SQL : The Ultimate Guide (2025)'),(21,'SQL'),(22,'Toyota'),(23,'xe điện'),(24,'Photoshop & Design For Content Marketing'),(25,' ads & Social Media'),(26,'Photoshop & Design '),(27,'Sử Dụng Hiệu Quả Các Công Cụ AI Miễn Phí'),(28,'Sử Dụng Các Công Cụ AI Miễn Phí'),(29,' Công Cụ AI Miễn Phí'),(30,'Complete Blender Creator: Learn 3D Modelling for Beginners'),(31,'Blender Creator: Learn 3D Modelling for Beginners'),(32,'Learn 3D Modelling for Beginners'),(33,'Khóa học AWS Cloud for Beginner tiếng Việt'),(34,'Khóa học AWS cho người mới bắt đầu'),(35,'DevOps on AWS for Beginner (Tiếng Việt)'),(36,'Khóa học DevOps + AWS'),(37,'tech pranks'),(38,'trò đùa IT'),(39,'prank on coworkers'),(40,'Top 10 Tech Pranks'),(41,'Game PC'),(42,'Những Tựa Game PC Được Mong Chờ Nhất Trong Năm 2025'),(43,'Google Earth Pro'),(44,'JPEG'),(45,'React'),(46,'React.JS'),(47,'Python'),(48,'Django'),(49,'FULLSTACK'),(50,'ASP.NET'),(51,'Web API'),(52,'NodeJS'),(53,'GraphQL'),(54,'Deno'),(55,'REST APIs'),(56,'Deep Learning'),(57,'Data Science'),(58,'Neural Network'),(59,'Computer Vision'),(60,'OpenCV'),(61,'java'),(62,'spring boot'),(63,'spring boot microservices'),(64,'chứng khoán'),(65,'VN-Index'),(66,'Góc nhìn chuyên gia'),(67,'VPBank'),(68,'FiinTrade'),(69,'Ripple'),(70,'ICP'),(71,'Video Editing Masterclass: Edit Your Videos Like a Pro!'),(72,'Video Editing '),(73,'Edit Videos '),(74,'After Effects LoopFlow Tạo Video Loop Cực Chất Từ Ảnh Tĩnh'),(75,'After Effects LoopFlow '),(76,'Tạo Video Loop Cực Chất Từ Ảnh Tĩnh'),(77,'Tạo Video Loop '),(78,'Tạo Video Loop Từ Ảnh Tĩnh'),(79,' LoopFlow'),(80,'Figma Prototype Từ A-Z dành cho UI/UX Designer'),(81,'Figma Prototype '),(82,'Figma Prototype Từ A-Z '),(83,'Figma Prototype dành cho UI/UX Designer'),(84,'Figma Prototype Course'),(85,'Business Analysis A to Z Masterclass'),(86,'Business Analysis'),(87,'Business Analysis A to Z'),(88,'BA'),(89,'Automotive product design using CATIA V5'),(90,'Automotive product design'),(91,'CATIA V5'),(92,'Automotive CATIA V5'),(93,'Modern Reinforcement Learning: Deep Q Agents (PyTorch & TF2)'),(94,'Deep Q Agents (PyTorch & TF2)'),(95,'PyTorch & TF2)'),(96,'Modern Reinforcement Learning: Deep Q Agents'),(97,'Modern Reinforcement '),(98,'GIMP 2.10 Masterclass: From Beginner to Pro Photo Editing'),(99,'GIMP 2.10 Masterclass'),(100,'Photo Editing'),(101,'GIMP 2.10 '),(102,'GIMP'),(103,'Master the Coding Interview: Data Structures + Algorithms'),(104,'Master the Coding Interview'),(105,'Master the Coding'),(106,'Data Structures + Algorithms'),(107,'Coding Interview'),(108,'Coding Interview: Data Structures + Algorithms'),(109,'The Project Management Course Beginner to PROject Manager'),(110,'The Project Management '),(111,'Project Management Course Beginner to PROject Manager');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `urls`
--

DROP TABLE IF EXISTS `urls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `urls` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `seq_no` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `urls`
--

LOCK TABLES `urls` WRITE;
/*!40000 ALTER TABLE `urls` DISABLE KEYS */;
INSERT INTO `urls` VALUES (15,'https://drive.google.com/file/d/1TTaMdyA5ibHKE-xaQ_G2XQqhSupaBaJ9/view?usp=drive_link',1),(16,'https://drive.google.com/file/d/1TTaMdyA5ibHKE-xaQ_G2XQqhSupaBaJ9/view?usp=drive_link',2),(17,'https://drive.google.com/file/d/1TTaMdyA5ibHKE-xaQ_G2XQqhSupaBaJ9/view?usp=drive_link',3),(18,'https://drive.google.com/file/d/1TTaMdyA5ibHKE-xaQ_G2XQqhSupaBaJ9/view?usp=drive_link',1);
/*!40000 ALTER TABLE `urls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('ADMIN','MANAGER','USER') DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `created_by` bigint DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKibk1e3kaxy5sfyeekp8hbhnim` (`created_by`),
  KEY `FKci7xr690rvyv3bnfappbyh8x0` (`updated_by`),
  CONSTRAINT `FKci7xr690rvyv3bnfappbyh8x0` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `FKibk1e3kaxy5sfyeekp8hbhnim` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'2025-10-14 18:47:06.122575','2025-10-14 18:47:06.122575','phamvanhieu300198@gmail.com','admin','phạm','$2a$10$nQJtBDGAARzemBk6vA2.8OvWLCR0.tLcOD7yj.dCDkWL91u2jLZea','ADMIN','tuanhv',NULL,NULL),(2,'2025-10-14 18:50:33.710990','2025-10-14 18:53:47.412208','phamvanhieu300198@gmail.com','admin','phạm','$2a$10$b6ixoBi8Uha5Bb0kp..2N.t4cs5UL4e1TYWUdcy/zU0AmY9ZVis7y','USER',NULL,1,2),(3,'2025-10-15 12:17:13.502206','2025-10-15 12:17:13.502206','dibhuan@gmail.com','Henry','Ba','$2a$10$jYksrDZ6nHWlmfymNUaYiOMrRVYDpRCqdebpYwY5VCnriUVKOAZ0K','ADMIN','huandb',1,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-08  2:01:30
